// routes/auth.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db/database');
const { requireAuth, requireRole } = require('../middleware/auth');
const { logAction } = require('../utils/audit');
const router = express.Router();

// Simple in-memory rate limiting per IP+username to blunt brute-force login
// attempts. For a production deployment behind a real load balancer, move
// this to Redis or a proper rate-limit middleware instead.
const attempts = new Map(); // key -> { count, firstAt }
const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 8;

function tooManyAttempts(key) {
  const rec = attempts.get(key);
  if (!rec) return false;
  if (Date.now() - rec.firstAt > WINDOW_MS) { attempts.delete(key); return false; }
  return rec.count >= MAX_ATTEMPTS;
}
function recordFailedAttempt(key) {
  const rec = attempts.get(key) || { count: 0, firstAt: Date.now() };
  rec.count += 1;
  attempts.set(key, rec);
}
function clearAttempts(key) { attempts.delete(key); }

router.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required.' });

  const key = `${req.ip}:${username}`;
  if (tooManyAttempts(key)) {
    return res.status(429).json({ error: 'Too many failed attempts. Try again in a few minutes.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user) {
    recordFailedAttempt(key);
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  const ok = bcrypt.compareSync(password, user.password_hash);
  if (!ok) {
    recordFailedAttempt(key);
    logAction({ user: { id: user.id, username, role: user.role }, ip: req.ip }, 'Failed login', 'Incorrect password');
    return res.status(401).json({ error: 'Invalid username or password.' });
  }

  clearAttempts(key);
  const payload = { id: user.id, username: user.username, role: user.role, name: user.name };
  const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '8h' });

  logAction({ user: payload, ip: req.ip }, 'Login', `${user.name} signed in as ${user.role}`);

  res.json({ token, user: payload });
});

router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

router.post('/logout', requireAuth, (req, res) => {
  logAction(req, 'Logout', `${req.user.name} signed out`);
  // JWTs are stateless - real invalidation requires a server-side denylist
  // or short expiry + refresh tokens. 8h expiry above is the practical
  // control here; add a token blocklist table if you need instant revoke.
  res.json({ ok: true });
});

// Admin-only: change any user's password (also lets a user change their own).
router.post('/change-password', requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  if (!newPassword || newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  if (!bcrypt.compareSync(currentPassword || '', user.password_hash)) {
    return res.status(401).json({ error: 'Current password is incorrect.' });
  }
  const hash = bcrypt.hashSync(newPassword, 12);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, user.id);
  logAction(req, 'Password changed', `${req.user.name} changed their own password`);
  res.json({ ok: true });
});

// Admin-only: create a new staff/parent account
router.post('/users', requireAuth, requireRole('admin'), (req, res) => {
  const { username, password, role, name, email, linked_student_id } = req.body || {};
  if (!username || !password || !role || !name) return res.status(400).json({ error: 'username, password, role and name are required.' });
  if (!['admin', 'bursar', 'teacher', 'parent'].includes(role)) return res.status(400).json({ error: 'Invalid role.' });
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) return res.status(409).json({ error: 'That username is already taken.' });

  const hash = bcrypt.hashSync(password, 12);
  const info = db.prepare('INSERT INTO users (username, password_hash, role, name, email, linked_student_id) VALUES (?,?,?,?,?,?)')
    .run(username, hash, role, name, email || null, linked_student_id || null);
  logAction(req, 'User created', `Created ${role} account "${username}" (${name})`);
  res.status(201).json({ id: info.lastInsertRowid });
});

module.exports = router;
